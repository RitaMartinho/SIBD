<?php 
    include_once('../database/connection.php');
    include_once('../database/account.php');
    include_once('../database/user.php');
    include_once('../includes/sessions.php');
    
<<<<<<< HEAD
     $origin = getAccountID($_SESSION['username']);
=======
    $origin = getAccountID($_SESSION['username']);
>>>>>>> rita_branch
    if(checkIfSendMoneyIsPossible($_POST['quantity'], $_POST['destiny'], $origin)){
        header("Location:../pages/generalview_user.php");
    }else echo "NO GOOD";
?>