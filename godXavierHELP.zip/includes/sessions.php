<?php
  session_start(['cookie_httponly' => true]);
?>